<template>
  <div class="project-container">
    <h1 class="project-title">과제 제안서</h1>
    <div class="nav-buttons">
      <router-link class="nav-button active" :to="{ name: 'RecommendationProposal' }">과제 제안서</router-link>
      <router-link class="nav-button" :to="{ name: 'ActivityPlan' }">수행 계획서</router-link>
      <router-link class="nav-button" :to="{ name: 'Presentation' }">발표 자료</router-link>
      <router-link class="nav-button" :to="{ name: 'FinalReport' }">최종 보고서</router-link>
      <router-link class="nav-button" :to="{ name: 'Code' }">코드</router-link>
    </div>
  </div>

  
  <div class="container">
  <form @submit.prevent="handleSubmit">
    <div class="write-box">
      <div class="title-input">
        <input v-model="post.title" type="text" placeholder="제목" class="input" required style="border: none;" />
      </div>

      <input id="image-upload" type="file" @change="handleImageChange" style="display: none;" />

      <div v-if="post.image || selectedFiles.length > 0" class="image-delete">
        <p v-if="selectedFiles.length > 0">{{ selectedFiles.map(file => file.name).join(', ') }}</p>
        <p v-else>{{ post.image }}</p>
        <button type="button" @click="removeImage" class="remove-btn">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-square" viewBox="0 0 16 16">
            <path d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
            <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
          </svg>
        </button>
      </div>

      <div v-else class="image-box">
        <label for="image-upload" class="file-upload-label">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-file-earmark-arrow-up" viewBox="0 0 16 16">
            <path d="M8.5 11.5a.5.5 0 0 1-1 0V7.707L6.354 8.854a.5.5 0 1 1-.708-.708l2-2a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1-.708.708L8.5 7.707z"/>
            <path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2M9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5z"/>
          </svg> 첨부 파일
        </label>
        <p v-if="selectedFiles.length === 0">선택된 파일 없음</p>
        <div class="file-names">
          <p v-if="selectedFiles.length > 0">선택된 파일: {{ selectedFiles.map(file => file.name).join(', ') }}</p>
        </div>
        <img v-if="imagePreview" :src="imagePreview" alt="미리보기" width="200" />
      </div>
    </div> <!-- write-box 종료 -->

    <textarea v-model="post.content" placeholder="내용을 입력해주세요." class="textarea" required></textarea>

    <div class="button-group">
      <button type="button" class="cancel-button" @click="$router.go(-1)">취소</button>
      <button type="submit" class="write-button">{{ isEditing ? '수정' : '등록' }}</button>
    </div>
  </form>
</div>



  


</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import axios from "axios";

const route = useRoute();
const router = useRouter();

const post = ref({
  title: "",
  content: "",
  image: "",
});

const selectedImage = ref(null);
const selectedFiles = ref([]);
const imagePreview = ref(null); // imagePreview 변수 정의

const handleImageChange = (event) => {
  const files = event.target.files;
  selectedFiles.value = Array.from(files);

  if (files.length > 0) {
    const file = files[0];
    selectedImage.value = file;
    const reader = new FileReader();
    reader.onload = (e) => {
      imagePreview.value = e.target.result; // imagePreview가 업데이트되도록 확인
    };
    reader.readAsDataURL(file);
  }
};


const removeImage = () => {
  post.value.image = null;
  selectedImage.value = null;
  selectedFiles.value = [];  // 초기화해서 파일명이 안 남도록 함
  imagePreview.value = null; // 이미지 미리보기 초기화
};


const fetchPost = async (id) => {
try {
  const response = await axios.get(`/proposal/${id}`);
  post.value = response.data;
} catch (error) {
  console.error('Error fetching post:', error);
}
};


const handleSubmit = async () => {
  const formData = new FormData();
  formData.append("title", post.value.title);
  formData.append("content", post.value.content);
  formData.append("image", selectedImage.value);
  formData.append("removeImage", post.value.image ? "false" : "true");

try {
  await axios.put(`/proposal/${route.params.id}`, formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
  alert('게시물이 수정되었습니다.');
  router.push({ name: 'DetRecommendationProposal', params: { id: route.params.id } });
} catch (error) {
  console.error('Error updating post:', error);
}
};

onMounted(() => {
  if (route.params.id) {
    fetchPost(route.params.id);
  }
});
</script>

<style scoped>
  /* 스타일 추가 */
  .post-image {
   width: 100%;
   max-width: 600px;
   height: auto;
   margin-top: 10px;
 }

  /* 게시글 시작 */
  .project-container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
  }
  
  .project-title {
    text-align: left;
    margin-top: 20px;
  }
  
  .announcement-container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
  }
  
  .announcement-title {
    text-align: left;
    margin-top: 20px;
  }
  
  .nav-buttons {
    display: flex;
    margin: 50px 0 50px 0;
  }
  
  .nav-button {
    display: block;
    padding: 10px 20px;
    margin: 0 20px 0 0;
    background-color: #faca4e;
    color: #fff;
    text-align: center;
    text-decoration: none;
    border-radius: 50px;
    font-weight: bold;
  }
  
  .nav-button:hover {
    background-color: #ff981b;
  }
  
  .active {
    background-color: #e67e22;
  }
  
  .container {
    max-width: 1200px;
    margin: auto;
    padding: 20px;
    
  }
  
  h1 {
    font-size: 24px;
    text-align: center;
    margin-bottom: 20px;
  }
  
  .input {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: none;
    outline: none;
    color: black;
  }
  
  .title-input {
    border-bottom: solid 1px #EDEDED;
  }
  
  .input:focus {
    border-bottom: solid 1px #EDEDED;
    outline: none;
    color: black;
  }
  
  .textarea {
    width: 100%;
    padding: 30px;
    height: 350px;
    resize: none;
    border: none;
  }
  
  .button {
    display: block;
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #ffa500;
    color: white;
    font-size: 16px;
    cursor: pointer;
  }
  
  .button:hover {
    background-color: #e69500;
  }
  
  label {
    display: block;
    margin-bottom: 5px;
  }
  
  img {
    display: block;
    margin-top: 10px;
  }
  
  /* 게시판 작성 */
  .write-box {
    border: 1px solid #002d68;
    border-radius: 55px;
    padding: 40px 40px 20px 40px;
    display: block;
    margin-bottom: 30px;
  }
  
  #image {
    display: none;
  }
  
  .file-names {
    margin-top: 10px;
  }
  
  .write-file {
    display: flex;
    align-items: center;
    margin-top: 20px;
  }
  
  .file-upload-label {
    width: 120px;
    display: inline-block;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
  
  .write-file svg {
    color: #002D68;
  }
  
  form > div {
    margin-bottom: initial;
    display: initial;
    flex-direction: initial;
    align-items: initial;
  }
  
  .button-group {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: row; /* flex-direction을 초기화합니다 */
    gap: 10px; /* 버튼 간의 간격을 추가합니다 */
    margin: 80px 0;
  }
  
  .cancel-button,
  .write-button {
    border: 1px solid #002D68;
    background-color: white;
    padding: 10px 35px;
    margin: 10px;
  }

  .image-delete{
    display: flex;
    margin: 30px 0 30px 15px;
  }

  .image-box{
    display: flex;
  }

  .remove-btn {
    background-color: white;
    border: none;
  }

.image-delete p {
  margin: 0 10px 0 0;
}
</style>
