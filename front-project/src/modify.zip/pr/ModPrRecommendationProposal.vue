<template>
    관리자 과제 제안서 페이지 입니다.
    <button>글쓰기</button>
</template>

<script>
    export default {
    
    }
</script>


<style scoped src="@/assets/style/fourthmenu/RePro.css">



</style>